// Homepage layout for Joe Nissi Limo Services
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function Home() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    pickup: "",
    dropoff: "",
    vehicle: "",
    notes: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("https://formsubmit.co/ajax/sawunor@joenissi.com", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(form)
      });

      const result = await response.json();
      if (result.success) {
        alert("Booking submitted successfully!\nWe'll get back to you shortly.");
      } else {
        alert("There was an error submitting the form. Please try again.");
      }
    } catch (error) {
      alert("Error submitting booking. Please try again later.");
    }
  };

  return (
    <div className="bg-black text-white min-h-screen font-sans">
      {/* HERO SECTION */}
      <section className="relative h-[90vh] bg-cover bg-center" style={{ backgroundImage: "url('/images/denali-jet.jpg')" }}>
        <div className="bg-black/50 h-full w-full flex flex-col items-center justify-center text-center px-4">
          <h1 className="text-5xl font-bold mb-4">Joe Nissi Limo Services</h1>
          <p className="text-xl mb-6">Luxury on Wheels. Wherever You Go.</p>
          <Button className="text-lg px-6 py-3 bg-gold hover:bg-gold-dark">Book Now</Button>
        </div>
      </section>

      {/* ABOUT SECTION */}
      <section className="py-16 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-6 text-gold">About Us</h2>
        <p className="text-lg leading-relaxed">
          Joe Nissi Limo Services is Atlanta’s premier luxury transportation provider. With a commitment to excellence, we specialize in providing VIP experiences for corporate clients, weddings, airport pickups, college tours, and special occasions.
        </p>
      </section>

      {/* SERVICES */}
      <section className="py-16 px-6 bg-gray-900 text-white">
        <h2 className="text-3xl font-bold mb-10 text-gold text-center">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {["Corporate Charters","Weddings & Anniversaries","Proms & Graduations","Airport Transfers","College Tours","Special Occasions"].map(service => (
            <Card key={service} className="bg-black border-gold text-white">
              <CardContent className="p-6 text-center">
                <h3 className="text-xl font-semibold mb-2">{service}</h3>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* FLEET */}
      <section className="py-16 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-6 text-gold">Our Fleet</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          <div>
            <img src="/images/gmc-denali.jpg" alt="GMC Denali" className="rounded-xl shadow-xl" />
            <h4 className="mt-4 text-xl font-medium">2024 GMC Denali</h4>
          </div>
        </div>
      </section>

      {/* BOOKING SECTION */}
      <section className="py-16 px-6 bg-gray-900 text-white">
        <h2 className="text-3xl font-bold mb-6 text-gold text-center">Book Your Ride</h2>
        <form action="https://formsubmit.co/sawunor@joenissi.com" method="POST" className="max-w-3xl mx-auto grid gap-4">
          <input type="hidden" name="_autoresponse" value="Thank you for booking with Joe Nissi Limo Services. We will confirm your ride shortly." />
          <input type="hidden" name="_next" value="https://joenissi.com/thank-you" />
          <input type="hidden" name="_captcha" value="false" />

          <div>
            <Label htmlFor="name">Full Name</Label>
            <Input name="name" value={form.name} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input name="email" value={form.email} onChange={handleChange} required type="email" />
          </div>
          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input name="phone" value={form.phone} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="date">Date of Ride</Label>
            <Input name="date" value={form.date} onChange={handleChange} type="date" required />
          </div>
          <div>
            <Label htmlFor="pickup">Pickup Location</Label>
            <Input name="pickup" value={form.pickup} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="dropoff">Drop-off Location</Label>
            <Input name="dropoff" value={form.dropoff} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="vehicle">Vehicle</Label>
            <Input name="vehicle" value={form.vehicle} onChange={handleChange} placeholder="e.g., GMC Denali" required />
          </div>
          <div>
            <Label htmlFor="notes">Additional Notes</Label>
            <Textarea name="notes" value={form.notes} onChange={handleChange} rows={3} />
          </div>
          <Button type="submit" className="bg-gold hover:bg-gold-dark">Submit Booking</Button>
        </form>
      </section>

      {/* CONTACT */}
      <section className="py-16 px-6 max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold mb-6 text-gold">Contact Us</h2>
        <p className="mb-2">📞 (770) 318-3719</p>
        <p className="mb-2">📧 sawunor@joenissi.com</p>
        <p>📍 Based in Atlanta, GA</p>
      </section>

      {/* FOOTER */}
      <footer className="bg-black text-center py-6 border-t border-gray-800">
        <p className="text-gray-400">© {new Date().getFullYear()} Joe Nissi Limo Services. All rights reserved.</p>
      </footer>
    </div>
  );
}
